using UnityEngine;
using Verse;

namespace RoRASettings
{
    public class RoRASettings : ModSettings
    {
        public int RoRAversionNumber;


        public override void ExposeData()
        {
            Scribe_Values.Look(ref RoRAversionNumber, "RoRAversionNumber");
            base.ExposeData();
        }

        public class RoRAMod : Mod
        {
            private readonly RoRASettings settings1;

            public RoRAMod(ModContentPack content) : base(content)
            {
                settings1 = GetSettings<RoRASettings>();
            }

            public override void DoSettingsWindowContents(Rect inRect)
            {
                var listing_Standard = new Listing_Standard();
                listing_Standard.Begin(inRect);
                listing_Standard.Label("RoRAUsePatchCEDesc".Translate());
                if (listing_Standard.RadioButton("RoRAUsePatchVanilla".Translate(),
                    settings1.RoRAversionNumber == 0, 8f))
                {
                    settings1.RoRAversionNumber = 0;
                }

                if (listing_Standard.RadioButton("RoRAUsePatchCE15".Translate(),
                    settings1.RoRAversionNumber == 1, 8f))
                {
                    settings1.RoRAversionNumber = 1;
                    Log.Message("[RoR Armors] Settings: Patch 1.5 Selected");
                }

                if (listing_Standard.RadioButton("RoRAUsePatchCE16".Translate(),
                    settings1.RoRAversionNumber == 2, 8f))
                {
                    settings1.RoRAversionNumber = 2;
                    Log.Message("[RoR Armors] Settings: Patch 1.6 Selected");
                }

                listing_Standard.End();
            }

            public override string SettingsCategory()
            {
                return "RoRASettingsModName".Translate();
            }
        }
    }
}
