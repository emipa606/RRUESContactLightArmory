using System.Collections.Generic;
using System.Xml;
using Verse;

namespace RoRASettings
{
    public class PatchOperationModVersion : PatchOperation
    {
        private PatchOperation match;

        private List<string> mods;

        private List<int> modSettingverNum;

        private PatchOperation nomatch;


        protected override bool ApplyWorker(XmlDocument xml)
        {
            var hasActiveMod = false;
            var hasRightVersion = false;
            foreach (var name in mods)
            {
                if (!ModLister.HasActiveModWithName(name))
                {
                    continue;
                }

                hasActiveMod = true;
                break;
            }

            foreach (var checkedout in modSettingverNum)
            {
                if (!CheckSettingsVersionNumber(checkedout))
                {
                    continue;
                }

                hasRightVersion = true;
                break;
            }

            if (!hasActiveMod || !hasRightVersion)
            {
                return true;
            }

            Log.Message("[RoR Armors] PatchOperationModVersion passed: Loading selected patch");
            if (match != null)
            {
                return match.Apply(xml);
            }

            if (nomatch != null)
            {
                return nomatch.Apply(xml);
            }

            return true;
        }

        public override string ToString()
        {
            return $"{base.ToString()}({mods.ToCommaList()})";
        }

        public static bool CheckSettingsVersionNumber(int checkedout)
        {
            var roRAversionNumber = LoadedModManager.GetMod<RoRASettings.RoRAMod>().GetSettings<RoRASettings>()
                .RoRAversionNumber;
            return roRAversionNumber == checkedout;
        }
    }
}
